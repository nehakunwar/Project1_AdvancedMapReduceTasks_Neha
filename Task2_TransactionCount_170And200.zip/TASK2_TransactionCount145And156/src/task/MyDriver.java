package task;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
    public static void main(String args[]) throws IOException, ClassNotFoundException, InterruptedException{
    	Configuration conf = new Configuration();
    	System.out.println("Use Case 1 : Count All the Transaction between a lower and upper amountt limit ");
    	System.out.println("=============================================================================== ");
    	System.out.println("=============================================================================== ");
		try{
    	Scanner src = new Scanner(System.in);
		System.out.print("Enter the minimum amount  ");
		int minamt = src.nextInt();
		
		conf.setInt("MinAmount", minamt);
		System.out.print("Enter the maximum amount  ");
		int maxamt = src.nextInt();
		
		if(maxamt<minamt){
			System.out.println("===========================Maximum value can't be less than minimum. Run the job again=======================");
		    System.exit(0);			
		}
		
		if(minamt<0){
			System.out.println("===========================Minimum value can't be less than 0. Run the job again=======================");
		    System.exit(0);			
		}
		if(maxamt<=0){
			System.out.println("===========================Maximum value must be greater than 0. Run the job again=======================");
		    System.exit(0);			
		}

		conf.setInt("MaxAmount", maxamt);
		}catch(InputMismatchException ie){
			System.out.println("Invalid input ! Please try again with valid inputs in number");
		}
		Job j = new Job(conf, "Output");
		j.setJarByClass(MyDriver.class);
		j.setMapperClass(MyMapper.class);
		j.setNumReduceTasks(1);
		j.setReducerClass(MyReducer.class);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(IntWritable.class);
		j.setInputFormatClass(MyInputFormat.class);
		
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path (args[1]));
		FileSystem hdfs = FileSystem.get(conf);
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
			hdfs.delete(newpath,true);
		}
		Path localfilepath = new Path("/home/hduser/sample/");
		if(j.waitForCompletion(true)){
	    	System.out.println("=============================================================================== ");
			hdfs.copyToLocalFile(newpath, localfilepath);
		}
        
		System.exit(j.waitForCompletion(true)?0:1);

    }
}
