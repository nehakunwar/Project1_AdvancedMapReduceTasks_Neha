package task;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MyMapper extends Mapper<MyKey, MyValue, Text, IntWritable> {
	
	public void map(MyKey inpK, MyValue inpV, Context c) throws IOException, InterruptedException{
		Configuration cfg=c.getConfiguration();
		
		double amt = inpV.getAmt();
		double minamt=Double.parseDouble(cfg.get("MinAmount"));
		double maxamt=Double.parseDouble(cfg.get("MaxAmount"));
		if(amt>minamt & amt<maxamt){
			c.write(new Text("Output"),new IntWritable(1));
		}
	}

}
