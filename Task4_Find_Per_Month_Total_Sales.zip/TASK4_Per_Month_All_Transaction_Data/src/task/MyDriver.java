package task;

import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MyDriver {
    public static void main(String args[]) throws IOException, ClassNotFoundException, InterruptedException{
    	HashMap<String,Integer> hm=new HashMap<String,Integer>();
    	hm.put("jan", 1);hm.put("feb", 2);hm.put("mar", 3);hm.put("apr", 4);hm.put("may", 5);hm.put("june", 6);hm.put("july", 7);
    	hm.put("aug", 8);hm.put("sep", 9);hm.put("oct", 10);hm.put("nov", 11);hm.put("dec", 12);
    	
    	Configuration conf = new Configuration();
    	System.out.println("Use Case 4 : Calculate total sales amt for each Month.");
    	System.out.println("=============================================================================== ");
    	System.out.println("=============================================================================== ");
		try{
    	Scanner src = new Scanner(System.in);
		System.out.println("Enter the number of month for which you want to generate report");
		System.out.println("Enter 0 to generate report for each month ");
		String choice=src.nextLine();
		if(choice.contains("01")|choice.contains("02")|choice.contains("03")|choice.contains("04")|choice.contains("05")|choice.contains("06")|choice.contains("07")|choice.contains("08")|choice.contains("09")|choice.contains("10")|choice.contains("11")|choice.contains("12")){
			int month=Integer.parseInt(choice);
			conf.setInt("Month", month);
		}else if(Integer.parseInt(choice)==0){
			int month=0;
		    conf.setInt("Month",month);
		}
		else{
			int month=hm.get(choice.toLowerCase());
			conf.setInt("Month",month);
		}
		}catch(Exception e){}
		Job j = new Job(conf, "Output");
		j.setJarByClass(MyDriver.class);
		j.setMapperClass(MyMapper.class);
		j.setNumReduceTasks(1);
		j.setReducerClass(MyReducer.class);
		j.setMapOutputKeyClass(Text.class);
		j.setMapOutputValueClass(DoubleWritable.class);
		j.setInputFormatClass(MyInputFormat.class);
		
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path (args[1]));
		FileSystem hdfs = FileSystem.get(conf);
		Path newpath = new Path(args[1]);
		if(hdfs.exists(newpath)){
			hdfs.delete(newpath,true);
		}
		Path localfilepath = new Path("/home/hduser/sample/");
		if(j.waitForCompletion(true)){
	    	System.out.println("=============================================================================== ");
			hdfs.copyToLocalFile(newpath, localfilepath);
		}
        
		System.exit(j.waitForCompletion(true)?0:1);

    }
}
